import { createGlobalStyle } from "styled-components";


export const Generic = createGlobalStyle`
    body {
        height: 100vh;
        width: 100vw ;
    }
`