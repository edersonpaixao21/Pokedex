import Style from "./style"


function Loandig(){
    return (
        <Style.Wrapper>
            <Style.Loanding>Loandig...</Style.Loanding>
        </Style.Wrapper>
    )
}

export default Loandig