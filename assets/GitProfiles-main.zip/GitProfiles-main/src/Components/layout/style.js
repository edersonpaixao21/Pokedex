import styled from "styled-components";

const Style = {};

Style.Wrapper = styled.div`
  background-color: #141c2f;
  width: 100%;
  min-height: 100vh;
  height: 100%;
  padding: 5px;
`;

export default Style;
